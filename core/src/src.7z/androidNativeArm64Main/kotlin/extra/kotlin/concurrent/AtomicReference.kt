package extra.kotlin.concurrent

actual typealias AtomicReference<T> = kotlin.native.concurrent.AtomicReference<T>
