package extra.kotlin.concurrent

actual typealias AtomicLong = kotlin.native.concurrent.AtomicLong
