package extra.kotlin.concurrent

actual typealias AtomicInt = kotlin.native.concurrent.AtomicInt
