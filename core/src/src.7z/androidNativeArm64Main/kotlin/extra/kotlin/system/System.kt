package extra.kotlin.system

import kotlin.system.getTimeMillis

actual fun getCurrentTimeInMillis(): Long = getTimeMillis()